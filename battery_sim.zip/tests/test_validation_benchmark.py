"""
Unit tests for Phase 4: Validation & Benchmark Engine
=====================================================
Verifies:
  1. Fixed-Threshold Monitor false alarm on cold sub-zero cell (-10 deg C).
  2. Fixed-Threshold Monitor silent failure / missed detection on voltage sensor bias (+35 mV).
  3. Adaptive Reference Monitor context-aware detection & alert generation.
  4. BenchmarkRunner execution and aggregate metric calculation.
  5. Phase 4 Dashboard 100% offline air-gapped integrity (zero CDN / external script dependencies).
"""

from __future__ import annotations
import os
import unittest
from pathlib import Path

from battery_sim.cell_model import BatteryCell, CellParameters
from battery_sim.reference_model import BaselineCalibrator
from battery_sim.fault_attribution import (
    FaultType,
    FaultScenarioConfig,
    FaultyCell,
)
from battery_sim.validation import (
    AlertSeverity,
    AlertEvent,
    FixedThresholdConfig,
    FixedThresholdMonitor,
    AdaptiveMonitorConfig,
    AdaptiveReferenceMonitor,
    BenchmarkRunner,
    BenchmarkSummary,
)
from battery_sim.visualizer import generate_phase4_dashboard


class TestValidationBenchmark(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        # Calibrate a standard reference baseline once for fast unit tests
        cal_cell = BatteryCell(params=CellParameters.default_nmc(), initial_soc=1.0, initial_temp_c=25.0)
        cls.baseline = BaselineCalibrator(cal_cell, cell_id="TEST-REF").build()

    def test_fixed_threshold_cold_false_alarm(self):
        """
        At -10 deg C sub-zero ambient temperature, a healthy cell's resistance naturally
        rises ~2.5x due to standard Arrhenius kinetics.
        Static threshold monitor (cutoff = 55 mOhm) trips a false alarm on healthy cells.
        The Adaptive Reference Model anticipates Arrhenius rise and avoids false alarms.
        """
        # Healthy nominal cell at -10 deg C
        cold_cell = BatteryCell(params=CellParameters.default_nmc(), initial_soc=0.8, initial_temp_c=-10.0)
        fixed_mon = FixedThresholdMonitor()
        ref_cell = BatteryCell(params=CellParameters.default_nmc(), initial_soc=0.8, initial_temp_c=-10.0)
        adapt_mon = AdaptiveReferenceMonitor(baseline=self.baseline, cell=ref_cell)

        # Step healthy cell under light discharge at -10 deg C
        diag = cold_cell.step(current=2.0, ambient_temp_c=-10.0, dt=2.0)

        # Fixed monitor check
        fixed_alerts = fixed_mon.check_step(
            time_s=2.0,
            v_measured=diag["v_terminal"],
            current_a=diag["current"],
            cell_temp_c=diag["cell_temp_c"],
            dcir_measured_mohm=diag["r0_mohm"],
        )

        # Adaptive monitor check
        adapt_alerts, dev = adapt_mon.check_step(
            time_s=2.0,
            v_measured=diag["v_terminal"],
            current_a=diag["current"],
            soc=diag["soc"],
            cell_temp_c=diag["cell_temp_c"],
            ambient_temp_c=-10.0,
            dcir_measured_mohm=diag["r0_mohm"],
            dt=2.0,
        )

        # Cold DCIR should be high (> 55 mOhm)
        self.assertGreater(diag["r0_mohm"], 55.0)
        # Fixed monitor trips false alarm on healthy cell
        self.assertTrue(fixed_mon.has_tripped)
        self.assertTrue(any(a.parameter == "IMPEDANCE" for a in fixed_alerts))

        # Adaptive monitor knows expected cold DCIR (Arrhenius factor) so relative residual is low
        self.assertLess(abs(dev.dcir_residual_pct), 20.0)

    def test_fixed_threshold_voltage_bias_missed(self):
        """
        A +35 mV ADC voltage sensor bias leaves voltage at ~3.835V, well within
        static BMS limits (2.75V - 4.25V). Fixed threshold monitor misses it (false negative).
        The Adaptive Reference Model detects the 35 mV residual against expected baseline.
        """
        base_cell = BatteryCell(params=CellParameters.default_nmc(), initial_soc=0.8, initial_temp_c=25.0)
        faulty = FaultyCell(
            base_cell=base_cell,
            config=FaultScenarioConfig(fault_type=FaultType.VOLTAGE_SENSOR_BIAS, voltage_bias_v=0.035),
            seed=1,
        )
        ref_cell = BatteryCell(params=CellParameters.default_nmc(), initial_soc=0.8, initial_temp_c=25.0)

        fixed_mon = FixedThresholdMonitor()
        adapt_mon = AdaptiveReferenceMonitor(baseline=self.baseline, cell=ref_cell)

        # Simulate 10 steps
        for step in range(10):
            t = (step + 1) * 2.0
            diag = faulty.step(current=1.5, ambient_temp_c=25.0, dt=2.0)
            fixed_mon.check_step(
                time_s=t,
                v_measured=diag["v_terminal"],
                current_a=diag["current"],
                cell_temp_c=diag["cell_temp_c"],
                dcir_measured_mohm=diag["r0_mohm"],
            )
            adapt_mon.check_step(
                time_s=t,
                v_measured=diag["v_terminal"],
                current_a=diag["current"],
                soc=diag["soc"],
                cell_temp_c=diag["cell_temp_c"],
                ambient_temp_c=25.0,
                dcir_measured_mohm=diag["r0_mohm"],
                dt=2.0,
            )

        # Fixed monitor never trips (silent failure)
        self.assertFalse(fixed_mon.has_tripped)
        self.assertEqual(len(fixed_mon.alerts), 0)

        # Adaptive monitor trips on voltage residual drift
        self.assertTrue(adapt_mon.has_tripped)
        self.assertTrue(any(a.parameter == "VOLTAGE" for a in adapt_mon.alerts))

    def test_adaptive_monitor_alert_generation(self):
        """Verifies AdaptiveReferenceMonitor generates properly structured AlertEvents."""
        cell = BatteryCell(params=CellParameters.default_nmc(), initial_soc=0.8, initial_temp_c=25.0)
        ref_cell = BatteryCell(params=CellParameters.default_nmc(), initial_soc=0.8, initial_temp_c=25.0)
        config = AdaptiveMonitorConfig(v_residual_warn_mv=30.0, v_residual_crit_mv=70.0)
        mon = AdaptiveReferenceMonitor(baseline=self.baseline, cell=ref_cell, config=config)

        # Force a large voltage residual by passing high v_measured
        alerts, dev = mon.check_step(
            time_s=10.0,
            v_measured=4.10,  # ~150 mV above expected ~3.95V
            current_a=0.0,
            soc=0.80,
            cell_temp_c=25.0,
            ambient_temp_c=25.0,
            dcir_measured_mohm=25.0,
            dt=1.0,
        )

        self.assertTrue(len(alerts) > 0)
        evt = alerts[0]
        self.assertIsInstance(evt, AlertEvent)
        self.assertEqual(evt.source_monitor, "ADAPTIVE_MODEL")
        self.assertEqual(evt.parameter, "VOLTAGE")
        self.assertIn(evt.severity, (AlertSeverity.WARNING, AlertSeverity.CRITICAL))
        self.assertGreater(abs(evt.residual_or_delta), 30.0)

    def test_benchmark_runner_execution(self):
        """Executes BenchmarkRunner and validates quantitative comparison metrics."""
        runner = BenchmarkRunner(baseline=self.baseline)
        summary = runner.run_benchmark(sim_duration_s=360.0, dt=2.0)

        self.assertIsInstance(summary, BenchmarkSummary)
        self.assertEqual(summary.total_scenarios, 7)
        self.assertEqual(summary.fault_scenarios_count, 5)
        self.assertEqual(summary.nominal_scenarios_count, 2)

        # Adaptive method must outperform fixed threshold in accuracy and attribution
        self.assertGreaterEqual(summary.adaptive_accuracy_pct, 95.0)
        self.assertLessEqual(summary.adaptive_false_positive_rate_pct, 5.0)
        self.assertLessEqual(summary.adaptive_false_negative_rate_pct, 5.0)
        self.assertGreaterEqual(summary.adaptive_attribution_capability_pct, 95.0)

        # Fixed threshold must exhibit 0% attribution capability
        self.assertEqual(summary.fixed_attribution_capability_pct, 0.0)
        # Fixed threshold false negative rate should be high due to missed subtle faults
        self.assertGreater(summary.fixed_false_negative_rate_pct, 50.0)

    def test_phase4_dashboard_html_offline_integrity(self):
        """
        Generates Phase 4 dashboard and verifies 100% offline air-gapped guarantee:
        No CDN URLs, no external scripts or remote stylesheets.
        """
        output_file = "test_phase4_offline_check.html"
        try:
            sample_telemetry = [
                {
                    "time_s": float(t),
                    "v_terminal": 3.9 - 0.001 * t,
                    "current": 2.0,
                    "soc": 0.9 - 0.0005 * t,
                    "cell_temp_c": 25.0 + 0.02 * t,
                    "ambient_temp_c": 25.0,
                    "r0_mohm": 26.0,
                    "power_w": 7.8,
                }
                for t in range(0, 100, 2)
            ]

            path = generate_phase4_dashboard(
                telemetry=sample_telemetry,
                output_path=output_file,
                title="Test Offline Dashboard",
            )
            self.assertTrue(os.path.exists(path))

            with open(path, "r", encoding="utf-8") as f:
                content = f.read()

            # Ensure non-trivial content
            self.assertGreater(len(content), 5000)

            # Air-gapped / offline verification: Zero CDN references
            self.assertNotIn("cdn.jsdelivr.net", content)
            self.assertNotIn("cdnjs.cloudflare.com", content)
            self.assertNotIn("unpkg.com", content)

            # Ensure no remote scripts: `<script src="http`
            self.assertNotIn('<script src="http', content)
            self.assertNotIn('<link rel="stylesheet" href="http', content)

            # Ensure HTML5 Canvas elements exist
            self.assertIn("<canvas id=\"canvas-v\">", content)
            self.assertIn("<canvas id=\"canvas-dcir\">", content)
            self.assertIn("<canvas id=\"canvas-temp\">", content)
            self.assertIn("<canvas id=\"canvas-soc\">", content)
        finally:
            if os.path.exists(output_file):
                try:
                    os.remove(output_file)
                except OSError:
                    pass


if __name__ == "__main__":
    unittest.main()
